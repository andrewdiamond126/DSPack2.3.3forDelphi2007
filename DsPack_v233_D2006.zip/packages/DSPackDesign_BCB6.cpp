//---------------------------------------------------------------------------

#include <basepch.h>
#pragma hdrstop
USEFORMNS("BaseFilterEditor.pas", Basefiltereditor, FormBaseFilter);
USEFORMNS("MediaTypeEditor.pas", Mediatypeeditor, FormMediaType);
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
